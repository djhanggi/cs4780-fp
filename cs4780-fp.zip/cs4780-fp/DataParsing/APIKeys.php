<?php

require_once __DIR__."/../Loader.php";

class DataParsing_APIKeys {
	const CURRENT_KEY = 'PMGU2A6MWFLSHWF3P';
}